package engine.board;

public interface BoardManager {
	
	int getSplitDistance() ;
	
	//More Info in Board Class Section

}
