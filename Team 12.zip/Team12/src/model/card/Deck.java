package model.card;

import java.util.ArrayList;

public class Deck {
	
	private final String CARDS_FILE = "Cards.csv";
	private ArrayList<Card> cardsPool;
	
	public static void loadCardPool(BoardManager boardManager, GameManager gameManager) throws IOException {
		
	}
	
	public static ArrayList<Card> drawCards(){
		
	}

}
