package model.card.standard;

public class Seven extends Standard {
	
	//Attribues Inherited
	
	//Constructor
	
	public Seven(String name, String description, Suit suit, BoardManager boardManager, 
			GameManager gameManager){
		
		//Body
	}

}
