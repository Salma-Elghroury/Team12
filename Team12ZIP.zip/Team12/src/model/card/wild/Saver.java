package model.card.wild;

import engine.GameManager; 
import engine.board.BoardManager;

public class Saver extends Wild {
	
	public Saver (String name, String description, BoardManager boardManager, GameManager gameManager) {
		super(name,description,boardManager,gameManager);
	}

}
