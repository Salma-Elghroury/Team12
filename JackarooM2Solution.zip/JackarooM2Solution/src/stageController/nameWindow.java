package stageController;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class nameWindow {
	
	private Label enterName;
	private TextField nameField;
	private Button startButton;
	private Scene sceneName;

	public nameWindow () {
		this.enterName = new Label ("What Might Your Name Be?");
		this.nameField = new TextField();
		this.startButton = new Button ("Jackaroo!!!");
		VBox window = new VBox (50,enterName,nameField,startButton);
		window.setAlignment(Pos.CENTER);
		this.sceneName = new Scene (window,400,300);
	}

	public TextField getNameField() {return nameField;}
	
	public Label getEnterName() {return enterName;}

	public Button getStartButton() {return startButton;}

	public Scene getSceneName() {return sceneName;}
	
	
	
	

}
