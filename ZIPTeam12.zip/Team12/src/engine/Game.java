package engine; 

import engine.GameManager;   
import engine.board.Board;
import engine.board.BoardManager;
import model.Colour;
import model.player.*;
import model.card.*;

import java.util.*;
import java.io.IOException ;

public class Game implements GameManager {
	
	private final Board board ;	
	private final ArrayList<Player> players;
	private final ArrayList<Card> firePit;
	private int currentPlayerIndex;
	private int turn;
	
	public Game(String playerName) throws IOException{
		
		ArrayList<Colour> colourOrder = new ArrayList<Colour>(4);
		
		colourOrder.add(Colour.RED);
		colourOrder.add(Colour.GREEN);
		colourOrder.add(Colour.BLUE);
		colourOrder.add(Colour.YELLOW);
		
		Collections.shuffle(colourOrder);
		
		board = new Board(colourOrder, (GameManager) this);
		
		Deck.loadCardPool((BoardManager) board,(GameManager) this);
		
		Player human = new Player(playerName,colourOrder.get(0));
		CPU CPU_1 = new CPU("CPU 1",colourOrder.get(1), (BoardManager) board);
		CPU CPU_2 = new CPU("CPU 2",colourOrder.get(2), (BoardManager) board);
		CPU CPU_3 = new CPU("CPU 3",colourOrder.get(3), (BoardManager) board);
		
		players = new ArrayList<Player>(4);
		players.add(human);
		players.add(CPU_1);
		players.add(CPU_2);
		players.add(CPU_3);
		
		human.setHand(Deck.drawCards());
		CPU_1.setHand(Deck.drawCards());
		CPU_2.setHand(Deck.drawCards());
		CPU_3.setHand(Deck.drawCards());
		
		currentPlayerIndex = 0;
		turn = 0;
		firePit = new ArrayList<Card>();
	}

	public Board getBoard() {
		return board;
	}

	public ArrayList<Player> getPlayers() {
		return players;
	}

	public ArrayList<Card> getFirePit() {
		return firePit;
	}

}
