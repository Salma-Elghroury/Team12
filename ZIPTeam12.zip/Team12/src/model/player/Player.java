package model.player;

import engine.GameManager; 
import engine.board.BoardManager;
import model.card.Card;
import model.Colour;

import java.util.ArrayList;

public class Player {
	
	private final String name;
	private final Colour colour;
	private ArrayList<Card> hand;
	private final ArrayList<Marble> marbles;
	private Card selectedCard;
	private final ArrayList<Marble> selectedMarbles;
	
	public Player(String name, Colour colour){
		
		this.name = name ;
		this.colour = colour ;
		
		this.hand = new ArrayList<Card>();
		this.selectedMarbles = new ArrayList<Marble>();
		this.marbles = new ArrayList<Marble>();
		
		Marble marble1 = new Marble(colour);
		Marble marble2 = new Marble(colour);
		Marble marble3 = new Marble(colour);
		Marble marble4 = new Marble(colour);
		
		marbles.add(marble1);
		marbles.add(marble2);
		marbles.add(marble3);
		marbles.add(marble4);
		
		this.selectedCard = null;
	}

	public String getName() {
		return name;
	}

	public Colour getColour() {
		return colour;
	}

	public ArrayList<Card> getHand() {
		return hand;
	}

	public void setHand(ArrayList<Card> hand) {
		this.hand = hand;
	}

	public ArrayList<Marble> getMarbles() {
		return marbles;
	}

	public Card getSelectedCard() {
		return selectedCard;
	}

}
