package model;

public enum Colour {
	RED,GREEN,BLUE,YELLOW;
}
