package engine;

public interface GameManager {
	
	//Further Info in Milestone 2 

}
