package engine;

public interface GameManager {
	
	//More Info in Milestone 2

}
