package model.card;

import engine.GameManager;   
import engine.board.BoardManager;

import java.io.BufferedReader; //To Read CVS File
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException ;
import java.util.*;

import model.card.standard.*;
import model.card.wild.*;

public class Deck {
	
	private final static String CARDS_FILE = "Cards.csv" ;
	private static ArrayList<Card> cardsPool;
	
	public static void loadCardPool(BoardManager boardManager, GameManager gameManager) throws IOException {
		
		BufferedReader br = new BufferedReader(new FileReader(CARDS_FILE)) ;
		String line = "" ;
		ArrayList<String> readFile = new ArrayList<String>();
		
		while(br.readLine() != null) {
			line = br.readLine() ;
			readFile.add(line) ;
		}
		
		int size = readFile.size() ; //Size of CSV Lines
		
		for (int i = 0 ; i < size ; i++) {
			
			String current = readFile.get(i) ;
			String[] split = current.split(",") ;
	
				if (Integer.parseInt(split[0]) < 14) {
					
					Standard card = new Standard (split[2], split[3],Integer.parseInt(split[4]), Suit.valueOf(split[5]), boardManager, gameManager) ;
					
					switch (card.getRank()) {				
					case 1 : card = new Ace(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;      
					case 5: card = new Five(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					case 4: card = new Four(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					case 11: card = new Jack(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					case 13: card = new King(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					case 12: card = new Queen(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					case 7: card = new Seven(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					case 10: card = new Ten(split[2],split[3], Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					default: card = new Standard(split[2],split[3], Integer.parseInt(split[0]) ,Suit.valueOf(split[5]), boardManager, gameManager) ; break;
					
					}
					
					for (int k = 0 ; k < Integer.parseInt(split[1]) ; k++) {cardsPool.add(card);} 
					
					}
					
				else{
					
					Wild card ;
					
					switch (Integer.parseInt(split[4])){
					case 14: card = new Burner(split[2], split[3], boardManager, gameManager); break;
					default : card = new Saver(split[2],split[3], boardManager, gameManager); break;
					
					}	
					
					for (int k = 0 ; k < Integer.parseInt(split[1]) ; k++) {cardsPool.add(card);}
				}
		}
		
	}
	
	public static ArrayList<Card> drawCards() {
		
		Collections.shuffle(cardsPool) ;
		ArrayList<Card> hand = new ArrayList<>() ;
		
		
		while (!cardsPool.isEmpty()) {
			
		 for (int i = 0 ; i < 4 ; i++) {
			 Card usedCard =cardsPool.remove(i); 
			 hand.add(usedCard); 
			 
		 }
		
		
	} return hand ;
	
}
	}