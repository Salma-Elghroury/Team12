package model.card.wild;

import engine.GameManager; 
import engine.board.BoardManager;

public class Saver extends Wild {
	
	//Attributes Inherited
	
	//Constructor 
	
	public Saver (String name, String description, BoardManager boardManager, 
		      GameManager gameManager) {
	
		super(name, description, boardManager, gameManager);
	
	}

}
